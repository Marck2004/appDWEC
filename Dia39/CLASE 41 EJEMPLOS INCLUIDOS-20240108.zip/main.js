import { etiqueta } from './carrusel.js';

